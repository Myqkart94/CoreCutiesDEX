import { Chain, createConfig, WagmiConfig } from 'wagmi';
import { configureChains } from 'wagmi';
import { jsonRpcProvider } from 'wagmi/providers/jsonRpc';
import { publicProvider } from 'wagmi/providers/public';
import { getDefaultWallets, RainbowKitProvider } from '@rainbow-me/rainbowkit';
import '@rainbow-me/rainbowkit/styles.css';

const coreDAO: Chain = {
  id: 1116,
  name: 'CoreDAO',
  network: 'coredao',
  nativeCurrency: { name: 'CORE', symbol: 'CORE', decimals: 18 },
  rpcUrls: {
    default: { http: ['https://rpc.coredao.org'] },
    public: { http: ['https://rpc.coredao.org'] }
  },
  blockExplorers: {
    default: { name: 'CoreScan', url: 'https://scan.coredao.org' }
  }
};

const { chains, publicClient, webSocketPublicClient } = configureChains(
  [coreDAO],
  [
    jsonRpcProvider({ rpc: () => ({ http: 'https://rpc.coredao.org' }) }),
    publicProvider()
  ]
);

const { connectors } = getDefaultWallets({
  appName: 'Core Cuties DEX',
  projectId: 'YOUR_PROJECT_ID', // Replace with your WalletConnect project ID
  chains
});

const config = createConfig({
  autoConnect: true,
  connectors,
  publicClient,
  webSocketPublicClient
});

const Web3Provider = ({ children }: { children: React.ReactNode }) => {
  return (
    <WagmiConfig config={config}>
      <RainbowKitProvider chains={chains}>
        {children}
      </RainbowKitProvider>
    </WagmiConfig>
  );
};

export default Web3Provider;