export const TOKENS = {
  CCTR: {
    name: 'Corecuties Refection',
    symbol: 'CCTR',
    decimals: 8,
    address: '0x811af333e431f4a6283bfbb1e0cd244715fd9c54'
  },
  CORE: {
    name: 'Core',
    symbol: 'CORE',
    decimals: 18,
    address: '0x0000000000000000000000000000000000000000'
  },
  WCORE: {
    name: 'WCore',
    symbol: 'WCORE',
    decimals: 18,
    address: '0x40375c92d9faf44d2f9db9bd9ba41a3317a2404f'
  }
};

export const ROUTERS = {
  V2: '0xBb5e1777A331ED93E07cF043363e48d320eb96c4',
  V3: '0xb440626C02be5F62d6D7818486E5ae58a454d26e'
};

export const FACTORIES = {
  V2: '0x9E6d21E759A7A288b80eef94E4737D313D31c13f',
  V3: '0xa8a3AAD4f592b7f30d6514ee9A863A4cEFF6531D'
};

export const CHAIN_ID = 1116;