import axios from 'axios';
import { ethers } from 'ethers';
import { CHAIN_ID } from '../config/tokens';

export const executeSwap = async (txData: any, signer: ethers.Signer) => {
  try {
    const tx = await signer.sendTransaction(txData);
    await tx.wait();
    return tx.hash;
  } catch (error) {
    console.error('Swap execution failed:', error);
    throw error;
  }
};

export const getSwapRoute = async (
  srcToken: string,
  dstToken: string,
  amount: string,
  userAddress: string,
  slippage = 0.5
) => {
  try {
    const response = await axios.get(`https://api.icecreamswap.com/aggregator/${CHAIN_ID}`, {
      params: {
        src: srcToken,
        dst: dstToken,
        amount,
        from: userAddress,
        slippage
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching swap route:', error);
    throw error;
  }
};