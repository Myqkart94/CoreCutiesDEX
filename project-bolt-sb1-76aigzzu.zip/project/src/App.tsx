import React, { useState, useCallback, useEffect } from 'react';
import { ArrowDownUp, Settings, Info, Sun, Moon, LineChart, Wallet, History, Bell, TrendingUp, Droplets, Layers, Grid as Bridge } from 'lucide-react';
import { useAccount, useNetwork, useSwitchNetwork } from 'wagmi';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import toast, { Toaster } from 'react-hot-toast';
import { createChart } from 'lightweight-charts';
import { TOKENS, CHAIN_ID } from './config/tokens';
import { executeSwap, getSwapRoute } from './utils/swap';
import { useTokenBalance } from './hooks/useTokenBalance';
import { 
  PriceChart, 
  TokenSelector, 
  WalletPanel, 
  NetworkStatus,
  LiquidityPanel,
  StakingPanel,
  TransactionHistory,
  BridgeInterface
} from './components';

function App() {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const { address, isConnected } = useAccount();
  const { chain } = useNetwork();
  const { switchNetwork } = useSwitchNetwork();
  
  const [activeTab, setActiveTab] = useState('swap');
  const [fromToken, setFromToken] = useState(TOKENS.CORE.address);
  const [toToken, setToToken] = useState(TOKENS.CCTR.address);
  const [fromAmount, setFromAmount] = useState('');
  const [toAmount, setToAmount] = useState('');
  const [slippage, setSlippage] = useState('0.5');
  const [loading, setLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const fromBalance = useTokenBalance(fromToken);
  const toBalance = useTokenBalance(toToken);

  const handleSwap = async () => {
    if (!isConnected) {
      toast.error('Please connect your wallet');
      return;
    }

    if (chain?.id !== CHAIN_ID) {
      switchNetwork?.(CHAIN_ID);
      return;
    }

    try {
      setLoading(true);
      const route = await getSwapRoute(
        fromToken,
        toToken,
        fromAmount,
        address!,
        parseFloat(slippage)
      );

      if (!route) {
        toast.error('No route found for swap');
        return;
      }

      const txHash = await executeSwap(route.tx, address!);
      toast.success(`Swap successful! TX: ${txHash}`);
      setFromAmount('');
      setToAmount('');
    } catch (error) {
      console.error('Swap failed:', error);
      toast.error('Swap failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const switchTokens = useCallback(() => {
    setFromToken(toToken);
    setToToken(fromToken);
    setFromAmount(toAmount);
    setToAmount(fromAmount);
  }, [fromToken, toToken, fromAmount, toAmount]);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
      <Toaster position="top-right" />
      
      {/* Navigation */}
      <nav className={`border-b ${isDarkMode ? 'border-gray-800 bg-gray-900/90' : 'border-gray-200 bg-white/90'} backdrop-blur-lg sticky top-0 z-50`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <ArrowDownUp className={`w-8 h-8 ${isDarkMode ? 'text-purple-400' : 'text-purple-600'}`} />
              <span className={`ml-2 text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Core Cuties DEX
              </span>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={toggleTheme}
                className={`p-2 rounded-lg ${isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'}`}
              >
                {isDarkMode ? (
                  <Sun className="w-5 h-5 text-gray-400" />
                ) : (
                  <Moon className="w-5 h-5 text-gray-600" />
                )}
              </button>
              <ConnectButton />
              <button 
                onClick={() => setShowSettings(!showSettings)}
                className={`p-2 rounded-lg ${isDarkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'}`}
              >
                <Settings className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Panel - Charts & Stats */}
          <div className="lg:col-span-2 space-y-6">
            <div className={`rounded-2xl p-6 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-xl`}>
              <div className="flex items-center justify-between mb-4">
                <h2 className={`text-xl font-semibold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  Price Chart
                </h2>
                <div className="flex gap-2">
                  <button className={`px-3 py-1 rounded-lg ${isDarkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'}`}>
                    24H
                  </button>
                  <button className={`px-3 py-1 rounded-lg ${isDarkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'}`}>
                    1W
                  </button>
                  <button className={`px-3 py-1 rounded-lg ${isDarkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'}`}>
                    1M
                  </button>
                </div>
              </div>
              <div className="h-[400px]" id="chart"></div>
            </div>

            <div className={`grid grid-cols-1 md:grid-cols-3 gap-4`}>
              <div className={`rounded-xl p-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
                <h3 className={`text-sm font-medium ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  24h Volume
                </h3>
                <p className={`text-2xl font-bold mt-1 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  $1,234,567
                </p>
                <span className="text-green-500 text-sm">+5.67%</span>
              </div>
              <div className={`rounded-xl p-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
                <h3 className={`text-sm font-medium ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  Total Liquidity
                </h3>
                <p className={`text-2xl font-bold mt-1 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  $9,876,543
                </p>
                <span className="text-green-500 text-sm">+2.34%</span>
              </div>
              <div className={`rounded-xl p-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-lg`}>
                <h3 className={`text-sm font-medium ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  Gas Price
                </h3>
                <p className={`text-2xl font-bold mt-1 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                  25 Gwei
                </p>
                <span className="text-red-500 text-sm">-1.23%</span>
              </div>
            </div>
          </div>

          {/* Right Panel - Swap Interface */}
          <div className="space-y-6">
            <div className={`rounded-2xl p-6 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-xl`}>
              <div className="flex items-center justify-between mb-6">
                <div className="flex gap-4">
                  <button
                    onClick={() => setActiveTab('swap')}
                    className={`px-4 py-2 rounded-lg font-medium ${
                      activeTab === 'swap'
                        ? 'bg-purple-600 text-white'
                        : isDarkMode
                        ? 'text-gray-400 hover:bg-gray-700'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    Swap
                  </button>
                  <button
                    onClick={() => setActiveTab('limit')}
                    className={`px-4 py-2 rounded-lg font-medium ${
                      activeTab === 'limit'
                        ? 'bg-purple-600 text-white'
                        : isDarkMode
                        ? 'text-gray-400 hover:bg-gray-700'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    Limit
                  </button>
                </div>
                <button
                  onClick={() => setShowSettings(!showSettings)}
                  className={`p-2 rounded-lg ${isDarkMode ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`}
                >
                  <Settings className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                </button>
              </div>

              {/* Token Input Fields */}
              <div className={`bg-${isDarkMode ? 'gray-700' : 'gray-100'} rounded-xl p-4 mb-2`}>
                <div className="flex justify-between mb-2">
                  <label className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    From
                  </label>
                  <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    Balance: {fromBalance}
                  </span>
                </div>
                <div className="flex gap-4">
                  <input
                    type="number"
                    value={fromAmount}
                    onChange={(e) => setFromAmount(e.target.value)}
                    placeholder="0.0"
                    className={`bg-transparent text-2xl ${
                      isDarkMode ? 'text-white' : 'text-gray-900'
                    } outline-none flex-1`}
                    disabled={loading}
                  />
                  <select
                    value={fromToken}
                    onChange={(e) => setFromToken(e.target.value)}
                    className={`px-3 py-1 rounded-lg ${
                      isDarkMode
                        ? 'bg-gray-600 text-white hover:bg-gray-500'
                        : 'bg-white text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    {Object.entries(TOKENS).map(([symbol, token]) => (
                      <option key={token.address} value={token.address}>
                        {symbol}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex justify-center -my-3 relative z-10">
                <button
                  onClick={switchTokens}
                  className={`p-2 rounded-lg ${
                    isDarkMode
                      ? 'bg-gray-700 hover:bg-gray-600'
                      : 'bg-white hover:bg-gray-50'
                  } shadow-lg`}
                >
                  <ArrowDownUp className={`w-5 h-5 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`} />
                </button>
              </div>

              <div className={`bg-${isDarkMode ? 'gray-700' : 'gray-100'} rounded-xl p-4 mt-2`}>
                <div className="flex justify-between mb-2">
                  <label className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    To
                  </label>
                  <span className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    Balance: {toBalance}
                  </span>
                </div>
                <div className="flex gap-4">
                  <input
                    type="number"
                    value={toAmount}
                    onChange={(e) => setToAmount(e.target.value)}
                    placeholder="0.0"
                    className={`bg-transparent text-2xl ${
                      isDarkMode ? 'text-white' : 'text-gray-900'
                    } outline-none flex-1`}
                    disabled={loading}
                  />
                  <select
                    value={toToken}
                    onChange={(e) => setToToken(e.target.value)}
                    className={`px-3 py-1 rounded-lg ${
                      isDarkMode
                        ? 'bg-gray-600 text-white hover:bg-gray-500'
                        : 'bg-white text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    {Object.entries(TOKENS).map(([symbol, token]) => (
                      <option key={token.address} value={token.address}>
                        {symbol}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Swap Settings */}
              {showSettings && (
                <div className={`mt-4 p-4 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
                  <h3 className={`text-sm font-medium mb-2 ${isDarkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Slippage Tolerance
                  </h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSlippage('0.1')}
                      className={`px-3 py-1 rounded-lg ${
                        slippage === '0.1'
                          ? 'bg-purple-600 text-white'
                          : isDarkMode
                          ? 'bg-gray-600 text-gray-300'
                          : 'bg-white text-gray-600'
                      }`}
                    >
                      0.1%
                    </button>
                    <button
                      onClick={() => setSlippage('0.5')}
                      className={`px-3 py-1 rounded-lg ${
                        slippage === '0.5'
                          ? 'bg-purple-600 text-white'
                          : isDarkMode
                          ? 'bg-gray-600 text-gray-300'
                          : 'bg-white text-gray-600'
                      }`}
                    >
                      0.5%
                    </button>
                    <button
                      onClick={() => setSlippage('1.0')}
                      className={`px-3 py-1 rounded-lg ${
                        slippage === '1.0'
                          ? 'bg-purple-600 text-white'
                          : isDarkMode
                          ? 'bg-gray-600 text-gray-300'
                          : 'bg-white text-gray-600'
                      }`}
                    >
                      1.0%
                    </button>
                    <input
                      type="number"
                      value={slippage}
                      onChange={(e) => setSlippage(e.target.value)}
                      className={`w-20 px-3 py-1 rounded-lg ${
                        isDarkMode
                          ? 'bg-gray-600 text-white'
                          : 'bg-white text-gray-900'
                      }`}
                      placeholder="Custom"
                    />
                  </div>
                </div>
              )}

              <button
                onClick={handleSwap}
                disabled={loading || !isConnected || !fromAmount}
                className={`w-full py-4 mt-6 rounded-xl ${
                  isDarkMode
                    ? 'bg-purple-600 hover:bg-purple-700'
                    : 'bg-purple-500 hover:bg-purple-600'
                } text-white font-semibold transition-colors disabled:opacity-50`}
              >
                {loading ? 'Processing...' : !isConnected ? 'Connect Wallet' : 'Swap Tokens'}
              </button>

              <div className={`mt-4 p-3 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'} flex items-start gap-2`}>
                <Info className={`w-5 h-5 ${isDarkMode ? 'text-purple-400' : 'text-purple-500'} flex-shrink-0 mt-0.5`} />
                <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Trading on Core Cuties DEX powered by IceCreamSwap. CCTR Token Contract:
                  <span className={`${isDarkMode ? 'text-purple-400' : 'text-purple-500'} break-all`}>
                    {' '}{TOKENS.CCTR.address}
                  </span>
                </p>
              </div>
            </div>

            {/* Transaction History */}
            <div className={`rounded-2xl p-6 ${isDarkMode ? 'bg-gray-800' : 'bg-white'} shadow-xl`}>
              <h2 className={`text-lg font-semibold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                Recent Transactions
              </h2>
              <div className="space-y-3">
                {/* Sample transactions - replace with real data */}
                <div className={`flex items-center justify-between p-3 rounded-lg ${isDarkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
                  <div className="flex items-center gap-3">
                    <ArrowDownUp className={`w-4 h-4 ${isDarkMode ? 'text-green-400' : 'text-green-500'}`} />
                    <div>
                      <p className={`text-sm font-medium ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                        Swap CORE → CCTR
                      </p>
                      <p className={`text-xs ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                        2 minutes ago
                      </p>
                    </div>
                  </div>
                  <span className={`text-sm ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                    0.5 CORE
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;