import { useEffect, useState } from 'react';
import { useAccount, useContractRead } from 'wagmi';
import { ethers } from 'ethers';
import { TOKENS } from '../config/tokens';

const ERC20_ABI = [
  'function balanceOf(address owner) view returns (uint256)',
  'function decimals() view returns (uint8)',
];

export function useTokenBalance(tokenAddress: string) {
  const { address } = useAccount();
  const [formattedBalance, setFormattedBalance] = useState<string>('0');

  const { data: balance } = useContractRead({
    address: tokenAddress as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'balanceOf',
    args: [address],
    watch: true,
    enabled: !!address && !!tokenAddress,
  });

  const { data: decimals } = useContractRead({
    address: tokenAddress as `0x${string}`,
    abi: ERC20_ABI,
    functionName: 'decimals',
    enabled: !!tokenAddress,
  });

  useEffect(() => {
    if (balance && decimals) {
      const formatted = ethers.formatUnits(balance.toString(), decimals);
      setFormattedBalance(Number(formatted).toFixed(6));
    }
  }, [balance, decimals]);

  return formattedBalance;
}