import "@openzeppelin/hardhat-upgrades";
import { getHardhatConfig } from "@icecreamswap/common/src/getHardhatConfig";

export default getHardhatConfig(["0.7.6"], 500);
