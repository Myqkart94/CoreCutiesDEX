# IceCreamSwap Farms and Pools

## Description

This repo includes MasterChef (ICE farms).
