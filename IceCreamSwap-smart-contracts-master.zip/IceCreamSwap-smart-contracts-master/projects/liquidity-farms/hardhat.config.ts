import { getHardhatConfig } from "@icecreamswap/common/src/getHardhatConfig";

export default getHardhatConfig(["0.6.12"]);
