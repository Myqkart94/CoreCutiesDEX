import { getHardhatConfig } from "@icecreamswap/common/src/getHardhatConfig";

export default getHardhatConfig(["0.8.10", "0.7.6"], 1_000);
